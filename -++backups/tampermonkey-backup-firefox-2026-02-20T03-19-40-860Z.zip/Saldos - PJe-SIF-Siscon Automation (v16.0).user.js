// ==UserScript==
// @name         Saldos - PJe/SIF/Siscon Automation (v16.0)
// @namespace    http://tampermonkey.net/
// @version      16.0
// @description  Volta ao básico: Lógica simples do teste de diagnóstico para evitar quebra de layout.
// @match        https://pje.trt2.jus.br/pjekz/processo/*/detalhe*
// @match        https://pje.trt2.jus.br/sif/consultar/*
// @match        https://alvaraeletronico.trt2.jus.br/portaltrtsp/pages/movimentacao/conta/buscar*
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        window.close
// ==/UserScript==

(function() {
    'use strict';

    const URL_ATUAL = window.location.href;
    const wait = (ms) => new Promise(r => setTimeout(r, ms));

    // --- FUNÇÃO SIMPLES (A mesma do Teste de Diagnóstico) ---
    // Sem 'view: window', sem 'unsafeWindow'. Apenas o básico.
    function dispararCliqueSimples(el) {
        if (!el) return;

        // Sequência que funcionou no teste (Opção 2)
        const evtOpts = { bubbles: true, cancelable: true };
        el.dispatchEvent(new MouseEvent('mousedown', evtOpts));
        el.dispatchEvent(new MouseEvent('mouseup', evtOpts));
        el.click(); // Click nativo final
    }

    // =========================================================================
    // PARTE 1: PJE (ORQUESTRADOR)
    // =========================================================================
    if (URL_ATUAL.includes('/pjekz/processo/') && URL_ATUAL.includes('/detalhe')) {
        console.log('[SALDOS] v16.0 Iniciada (Modo Simplificado)');

        // Interface limpa
        const divBtns = document.createElement('div');
        divBtns.style.cssText = 'position:fixed;top:120px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:5px;';

        const btnSif = document.createElement('button');
        btnSif.textContent = 'SIF (Menu)';
        btnSif.style.cssText = 'padding:8px 15px;background:#E65100;color:white;font-weight:bold;border:none;border-radius:4px;cursor:pointer;margin-bottom:5px;box-shadow:0 2px 4px rgba(0,0,0,0.3);';
        btnSif.onclick = navegarSif; // Chama direto, sem wrapper

        const btnSiscon = document.createElement('button');
        btnSiscon.textContent = 'Siscon (Menu)';
        btnSiscon.style.cssText = 'padding:8px 15px;background:#00695C;color:white;font-weight:bold;border:none;border-radius:4px;cursor:pointer;margin-bottom:5px;box-shadow:0 2px 4px rgba(0,0,0,0.3);';
        btnSiscon.onclick = navegarSiscon;

        divBtns.appendChild(btnSif);
        divBtns.appendChild(btnSiscon);
        document.body.appendChild(divBtns);

        setInterval(verificarRetornoWorker, 1000);

        async function navegarSif() {
            GM_setValue('SALDOS_STATUS', 'PENDENTE');
            GM_setValue('SALDOS_TIPO', 'SIF');

            console.log('[SIF] Procurando menu...');

            // Busca o botão
            let btnMenu = document.getElementById('botao-menu');
            if (!btnMenu) {
                const icone = document.querySelector('.fa-bars');
                if (icone) btnMenu = icone.closest('button');
            }

            if (!btnMenu) return alert('Botão Menu não encontrado!');

            // 1. CLIQUE NO MENU
            dispararCliqueSimples(btnMenu);

            // 2. ESPERA VISUAL (Timeout simples)
            // Não vamos bloquear a thread. Vamos verificar a cada 200ms
            let tentativas = 0;
            const checkItem = setInterval(() => {
                tentativas++;
                const itens = Array.from(document.querySelectorAll('button, a, span'));
                const btnFin = itens.find(el => el.textContent && el.textContent.includes('Dados Financeiros'));

                if (btnFin) {
                    clearInterval(checkItem);
                    // 3. CLIQUE NO ITEM (com pequeno delay para o Angular processar a animação)
                    setTimeout(() => {
                        const alvo = btnFin.closest('button') || btnFin;
                        dispararCliqueSimples(alvo);
                    }, 300);
                } else if (tentativas > 25) { // 5 segundos
                    clearInterval(checkItem);
                    console.log('Timeout esperando Dados Financeiros');
                }
            }, 200);
        }

        async function navegarSiscon() {
            GM_setValue('SALDOS_STATUS', 'PENDENTE');
            GM_setValue('SALDOS_TIPO', 'SISCON');

            const acionador = document.getElementById('avjt-painel-superior-acionador');
            if (acionador) {
                // Eventos nativos simples
                acionador.dispatchEvent(new MouseEvent('mouseover', {bubbles:true}));

                await wait(800);
                const btnSiscon = document.getElementById('botao-do-processo-siscondj');
                if (btnSiscon) {
                    btnSiscon.style.display = 'block';
                    btnSiscon.click();
                } else { alert('Botão Siscon não visível.'); }
            } else { alert('Painel superior não encontrado.'); }
        }

        function verificarRetornoWorker() {
            const status = GM_getValue('SALDOS_STATUS');
            if (status && status.startsWith('CONCLUIDO')) {
                GM_setValue('SALDOS_STATUS', 'IDLE');
                const tipo = GM_getValue('SALDOS_TIPO');
                const dados = GM_getValue('SALDOS_DADOS', '');

                if (status === 'CONCLUIDO_ZERADO') {
                    alert(`[${tipo}] SALDO ZERADO.`);
                } else {
                    exibirDialogConferencia(tipo, dados);
                }
            }
        }

        function exibirDialogConferencia(tipo, htmlDados) {
            const modal = document.createElement('div');
            modal.style.cssText = `position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 750px; max-height: 90vh; background: white; z-index: 100000; border: 2px solid #009688; box-shadow: 0 15px 50px rgba(0,0,0,0.5); border-radius: 8px; font-family: sans-serif; display: flex; flex-direction: column;`;

            const header = document.createElement('div');
            header.innerHTML = `<strong>⚖️ CONFERÊNCIA DE SALDO - ${tipo}</strong>`;
            header.style.cssText = 'background: #009688; color: white; padding: 15px; font-size: 16px; border-radius: 6px 6px 0 0;';

            const content = document.createElement('div');
            content.style.cssText = 'padding: 25px; overflow-y: auto; flex: 1; font-size: 14px; line-height: 1.6; color: #333;';
            if(htmlDados.includes('<div') || htmlDados.includes('<p')) content.innerHTML = htmlDados;
            else content.innerHTML = `<p>${htmlDados}</p>`;

            const footer = document.createElement('div');
            footer.style.cssText = 'padding: 15px; text-align: right; border-top: 1px solid #ddd; background: #f9f9f9; border-radius: 0 0 6px 6px;';

            const btnLib = document.createElement('button');
            btnLib.textContent = 'CONFIRMAR';
            btnLib.style.cssText = 'padding: 10px 20px; background: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer; margin-left:10px;';
            btnLib.onclick = () => { alert('Ok!'); modal.remove(); };

            const btnCancel = document.createElement('button');
            btnCancel.textContent = 'Fechar';
            btnCancel.style.cssText = 'padding: 10px 20px; background: #f44336; color: white; border: none; border-radius: 4px; cursor: pointer;';
            btnCancel.onclick = () => modal.remove();

            footer.appendChild(btnCancel);
            footer.appendChild(btnLib);
            modal.appendChild(header);
            modal.appendChild(content);
            modal.appendChild(footer);
            document.body.appendChild(modal);
        }
    }

    // =========================================================================
    // PARTE 2: WORKER SISCON (Mantido porque funcionou)
    // =========================================================================
    else if (URL_ATUAL.includes('alvaraeletronico.trt2.jus.br')) {
        const status = GM_getValue('SALDOS_STATUS');
        if (status !== 'PENDENTE' || GM_getValue('SALDOS_TIPO') !== 'SISCON') return;

        window.addEventListener('load', () => setTimeout(injetarCodigoSiscon, 1500));
        if (document.readyState === 'complete') setTimeout(injetarCodigoSiscon, 1500);

        function injetarCodigoSiscon() {
            if (document.getElementById('conta_inexistente')) {
                GM_setValue('SALDOS_STATUS', 'CONCLUIDO_ZERADO');
                setTimeout(() => window.close(), 1000);
                return;
            }

            const script = document.createElement('script');
            // Código do Siscon v13 (Estável)
            script.textContent = `
            (function() {
                function brlToFloat(txt) { if (!txt) return 0; const n = txt.replace(/R\\$/g, '').replace(/\\./g, '').replace(',', '.').replace(/\\s/g, '').trim(); const v = parseFloat(n); return Number.isFinite(v) ? v : 0; }
                function toBRL(n) { try { return n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }); } catch { return 'R$ ' + (Number(n) || 0).toFixed(2).replace('.', ','); } }

                function extrairDados() {
                    const tabelaContas = document.getElementById('table_contas');
                    if (!tabelaContas) return '';
                    const linhasContas = tabelaContas.querySelectorAll('tr[id^="linhaConta_"]');
                    const resultados = [];
                    linhasContas.forEach(linha => {
                        const idConta = linha.id.replace('linhaConta_', '');
                        const numeroConta = linha.querySelector('td:nth-child(2)')?.textContent?.trim() || 'Desconhecida';
                        const celulaValor = linha.querySelector('td[id^="td_saldo_corrigido_conta_"]');
                        const valorTotal = brlToFloat(celulaValor?.textContent);
                        if (valorTotal <= 0) return;
                        const depositos = [];
                        const tabelaParcelas = document.getElementById('tabela_parcelas_conta_' + idConta);
                        if (tabelaParcelas) {
                            const linhasP = tabelaParcelas.querySelectorAll('tbody > tr:not(:first-child)');
                            linhasP.forEach(tr => {
                                const cols = tr.querySelectorAll('td');
                                if (cols.length >= 8) {
                                    const dataDep = cols[2]?.textContent?.trim();
                                    const nomeDep = cols[3]?.textContent?.trim();
                                    let valTxt = '';
                                    const celulaSaldoP = tr.querySelector('td[id^="td_saldo_parcela_saldo_"]');
                                    if(celulaSaldoP) valTxt = celulaSaldoP.textContent.trim();
                                    else valTxt = cols[8]?.textContent?.trim();
                                    const valDep = brlToFloat(valTxt);
                                    if (valDep > 0 && dataDep && nomeDep) { depositos.push({ data: dataDep, nome: nomeDep, valor: valDep }); }
                                }
                            });
                        }
                        resultados.push({ conta: numeroConta, total: valorTotal, depositos: depositos });
                    });
                    const hoje = new Date();
                    const dataConf = \`\${String(hoje.getDate()).padStart(2,'0')}/\${String(hoje.getMonth()+1).padStart(2,'0')}/\${hoje.getFullYear()}\`;
                    let html = \`<div style="font-family: Arial, sans-serif; color: #333;"><p style="margin-bottom: 20px;"><strong>Data da conferência:</strong> \${dataConf}</p>\`;
                    if (resultados.length === 0) return '';
                    resultados.forEach((r, idx) => {
                        html += \`<div style="margin-bottom: 25px; padding-bottom: 15px; border-bottom: 1px solid #eee;"><p style="margin: 5px 0;"><strong>Conta Judicial:</strong> \${r.conta}</p><p style="margin: 5px 0;"><strong>Total Disponível:</strong> \${toBRL(r.total)}</p>\`;
                        if (r.depositos.length > 0) {
                            html += \`<p style="margin: 10px 0 5px 0; font-weight:bold; color:#00695C;">Discriminação de depósitos disponíveis:</p>\`;
                            r.depositos.forEach(d => { html += \`<p style="margin: 3px 0 3px 20px; font-size: 13px;">• \${d.data} - \${d.nome} - <strong>\${toBRL(d.valor)}</strong></p>\`; });
                        } else { html += \`<p style="margin: 5px 0; color:#d32f2f; font-style:italic;">(Consultar parcelas individuais - expandir detalhes na tela)</p>\`; }
                        html += \`</div>\`;
                    });
                    html += \`</div>\`;
                    return html;
                }
                function prepararAmbiente() {
                    const btnOmitir = document.getElementById('imgOmitirContasZeradas');
                    if (btnOmitir) { btnOmitir.click(); }
                    setTimeout(() => {
                        const linhas = document.querySelectorAll('tr[id^="linhaConta_"]');
                        let count = 0;
                        linhas.forEach(l => {
                            const val = brlToFloat(l.querySelector('td[id^="td_saldo_corrigido_conta_"]')?.textContent);
                            if (val > 0) {
                                const btnSoma = l.querySelector('img[src*="soma-ico"]');
                                const idConta = l.id.replace('linhaConta_', '');
                                const trParcela = document.getElementById('tabela_parcelas_conta_' + idConta);
                                if (btnSoma && (!trParcela || trParcela.style.display === 'none')) { btnSoma.click(); count++; }
                            }
                        });
                        const tempoEspera = count > 0 ? 3000 : 1500;
                        setTimeout(() => {
                            const resultado = extrairDados();
                            localStorage.setItem('SISCON_RESULT_TEMP', resultado);
                        }, tempoEspera);
                    }, 1000);
                }
                prepararAmbiente();
            })();`;
            document.body.appendChild(script);
            const waitLoop = setInterval(() => {
                const res = localStorage.getItem('SISCON_RESULT_TEMP');
                if (res !== null) {
                    clearInterval(waitLoop);
                    localStorage.removeItem('SISCON_RESULT_TEMP');
                    if (res && res.length > 20) { GM_setValue('SALDOS_DADOS', res); GM_setValue('SALDOS_STATUS', 'CONCLUIDO_COM_SALDO'); }
                    else { GM_setValue('SALDOS_STATUS', 'CONCLUIDO_ZERADO'); }
                    setTimeout(() => window.close(), 1000);
                }
            }, 500);
        }
    }
    // SIF (Worker - Mantido)
    else if (URL_ATUAL.includes('/sif/consultar')) {
        const status = GM_getValue('SALDOS_STATUS');
        if (status !== 'PENDENTE' || GM_getValue('SALDOS_TIPO') !== 'SIF') return;
        const checkInterval = setInterval(() => {
            const tabela = document.querySelector('table.mat-table');
            const msgErro = document.body.innerText.includes('Nenhum registro');
            if (msgErro) {
                clearInterval(checkInterval);
                GM_setValue('SALDOS_STATUS', 'CONCLUIDO_ZERADO');
                setTimeout(() => window.close(), 500);
            } else if (tabela) {
                let saldoTotal = 0;
                tabela.querySelectorAll('tbody tr').forEach(tr => {
                    const td = tr.querySelector('.cdk-column-saldoDisponivel');
                    if (td) saldoTotal += parseFloat(td.textContent.replace('R$','').replace(/\./g,'').replace(',','.').trim()) || 0;
                });
                GM_setValue('SALDOS_DADOS', `Saldo Total SIF: R$ ${saldoTotal.toFixed(2)}`);
                GM_setValue('SALDOS_STATUS', saldoTotal > 0 ? 'CONCLUIDO_COM_SALDO' : 'CONCLUIDO_ZERADO');
                clearInterval(checkInterval);
                setTimeout(() => window.close(), 500);
            }
        }, 1000);
    }
})();
