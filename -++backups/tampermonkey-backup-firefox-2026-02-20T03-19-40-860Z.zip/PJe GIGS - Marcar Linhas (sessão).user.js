// ==UserScript==
// @name         PJe GIGS - Marcar Linhas (sessão)
// @namespace    http://tampermonkey.net/
// @version      1.4
// @description  Marca linhas clicadas apenas enquanto a página está aberta
// @author       Você
// @match        https://pje.trt2.jus.br/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    console.log('[MARCAR_LINHAS] Script iniciado na URL:', window.location.href);

    function marcarLinha(tr) {
        tr.style.backgroundColor = '#ff9800'; // Laranja forte
        tr.style.opacity = '0.85';
        tr.style.borderLeft = '5px solid #ff6f00'; // Laranja escuro
        console.log('[MARCAR_LINHAS] Linha marcada!');
    }

    function processar() {
        const linhas = document.querySelectorAll('pje-data-table tbody tr');
        console.log('[MARCAR_LINHAS] Encontradas', linhas.length, 'linhas');

        linhas.forEach(tr => {
            tr.addEventListener('click', () => {
                marcarLinha(tr);
            }, { once: true });
        });
    }

    // Tenta várias vezes até achar a tabela
    function tentarProcessar(tentativas = 0) {
        const linhas = document.querySelectorAll('pje-data-table tbody tr');

        if (linhas.length > 0) {
            console.log('[MARCAR_LINHAS] ✅ Encontradas', linhas.length, 'linhas');
            processar();
        } else if (tentativas < 10) {
            console.log('[MARCAR_LINHAS] Tentativa', tentativas + 1, '- aguardando tabela...');
            setTimeout(() => tentarProcessar(tentativas + 1), 1000);
        } else {
            console.log('[MARCAR_LINHAS] ❌ Tabela não encontrada após 10 tentativas');
        }
    }

    tentarProcessar();

    // Observer para paginação
    const observer = new MutationObserver(() => {
        setTimeout(processar, 500);
    });

    setTimeout(() => {
        const container = document.querySelector('pje-data-table');
        if (container) {
            observer.observe(container, { childList: true, subtree: true });
            console.log('[MARCAR_LINHAS] Observer ativo');
        }
    }, 3000);
})();
