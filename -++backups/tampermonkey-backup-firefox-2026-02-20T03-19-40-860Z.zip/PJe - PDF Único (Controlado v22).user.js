// ==UserScript==
// @name         PJe - PDF Único (Controlado v22)
// @namespace    http://tampermonkey.net/
// @version      22.0
// @description  Botão de ativação manual. Correção do clique nativo (Input vs Label). Bloqueio de propagação ajustado.
// @author       SeuNome
// @match        https://*.jus.br/pjekz/processo/*/detalhe*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let isScriptActive = false;
    const selectedIds = new Set();

    // --- 1. CSS (Só será injetado ao ativar) ---
    const cssContent = `
        /* Esconde checkboxes APENAS na timeline após ativação */
        .tl-item-anexo mat-checkbox,
        .tl-item-desc mat-checkbox {
            opacity: 0 !important;
            width: 0 !important; margin: 0 !important; position: absolute !important; pointer-events: none !important;
        }
        .tl-item-anexo .tl-botao { min-width: 0 !important; }

        /* Destaque Visual */
        .pje-selected-v22 {
            background-color: #e3f2fd !important; /* Azul suave */
            border-left: 4px solid #1565c0 !important;
        }

        /* Botão de Ativação Flutuante */
        #btn-activate-v22 {
            position: fixed; bottom: 20px; right: 20px;
            background: #1565c0; color: white; padding: 12px 24px;
            border: none; border-radius: 50px; font-weight: bold; font-size: 14px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3); z-index: 999999; cursor: pointer;
            transition: transform 0.2s;
        }
        #btn-activate-v22:hover { transform: scale(1.05); }

        /* Painel da Lista */
        #pje-panel-v22 {
            position: fixed; bottom: 20px; right: 20px; width: 300px;
            background: #fff; border: 2px solid #1565c0;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3); z-index: 999999;
            font-family: Arial, sans-serif; border-radius: 8px;
            display: none; flex-direction: column;
        }
    `;

    // --- 2. INICIALIZAÇÃO ---
    function init() {
        if (!window.location.href.includes('/detalhe')) return;
        createActivateBtn();
    }

    function createActivateBtn() {
        if (document.getElementById('btn-activate-v22')) return;
        const btn = document.createElement('button');
        btn.id = 'btn-activate-v22';
        btn.innerText = 'ATIVAR SELEÇÃO DE PDF';
        btn.onclick = activateScript;
        document.body.appendChild(btn);
    }

    // --- 3. ATIVAÇÃO ---
    function activateScript() {
        const btn = document.getElementById('btn-activate-v22');
        if (btn) btn.style.display = 'none'; // Esconde botão de ativação

        // Injeta CSS
        const style = document.createElement('style');
        style.innerText = cssContent;
        document.head.appendChild(style);

        // Ativa modo nativo do PJe
        const nativeBtn = document.getElementById('exibirOcultarMultiplaSelecao');
        if (nativeBtn && nativeBtn.getAttribute('aria-label').includes('Exibir')) {
            nativeBtn.click();
        }

        isScriptActive = true;
        createPanel();
        startObserver();
        console.log('[PJe v22] Ativado.');
    }

    // --- 4. PAINEL ---
    function createPanel() {
        const panel = document.createElement('div');
        panel.id = 'pje-panel-v22';
        panel.style.display = 'flex';
        panel.innerHTML = `
            <div style="background: #1565c0; color: white; padding: 10px; font-weight: bold; border-radius: 6px 6px 0 0; display: flex; justify-content: space-between;">
                <span>Docs Selecionados (<span id="count-v22">0</span>)</span>
                <span id="close-v22" style="cursor:pointer">✕</span>
            </div>
            <div id="list-v22" style="max-height: 200px; overflow-y: auto; padding: 5px; background: #f5f5f5; border-bottom: 1px solid #ddd; font-size: 11px; min-height: 40px;">
                <div style="text-align:center; color:#888; padding:10px;">Clique nos nomes dos documentos</div>
            </div>
            <div style="padding: 10px; text-align: center;">
                <button id="btn-dl-v22" style="width: 100%; background: #1565c0; color: white; border: none; padding: 10px; border-radius: 4px; cursor: pointer; font-weight: bold;">
                    BAIXAR PDF ÚNICO
                </button>
            </div>
        `;
        document.body.appendChild(panel);

        document.getElementById('btn-dl-v22').addEventListener('click', doNativeDownload);
        document.getElementById('close-v22').addEventListener('click', () => {
            panel.style.display = 'none';
            document.getElementById('btn-activate-v22').style.display = 'block';
            isScriptActive = false;
            // Opcional: Remover CSS aqui se quiser voltar ao normal totalmente
        });
    }

    // --- 5. LÓGICA DE CLIQUE (CORRIGIDA) ---
    function startObserver() {
        document.body.addEventListener('click', (e) => {
            if (!isScriptActive) return;

            const target = e.target;

            // Ignora cliques no próprio painel do script ou inputs
            if (target.closest('#pje-panel-v22')) return;
            if (target.closest('button, input, mat-checkbox')) return;

            // Identifica área clicável (Texto/Link do doc)
            const clickZone = target.closest('.tl-documento, .tl-subitem-detalhe, .texto-doc');
            if (!clickZone) return;

            // Acha o container da linha (Anexo ou Pai)
            let container = clickZone.closest('.tl-item-anexo'); // Tenta Anexo
            let isAttachment = true;

            if (!container) {
                container = clickZone.closest('mat-card.tl-item-desc'); // Tenta Pai
                isAttachment = false;
            }

            if (container) {
                // Acha o checkbox correto
                let checkboxInput = null;

                if (isAttachment) {
                    checkboxInput = container.querySelector('mat-checkbox input');
                } else {
                    // No Pai, pega o checkbox que NÃO está em anexos filhos
                    const all = container.querySelectorAll('mat-checkbox input');
                    for (let cb of all) {
                        if (!cb.closest('.tl-item-anexo')) {
                            checkboxInput = cb;
                            break;
                        }
                    }
                }

                if (checkboxInput) {
                    // IMPEDIR PROPAGAÇÃO AQUI É CRUCIAL PARA NÃO SELECIONAR PAIS
                    e.stopPropagation();
                    // e.preventDefault(); // Removido para garantir que o clique flua, mas testar se necessário

                    // Dispara clique no checkbox
                    checkboxInput.click();

                    // Atualiza Visual (Baseado no estado real pós-clique)
                    setTimeout(() => {
                        updateState(container, checkboxInput);
                    }, 50);
                }
            }
        }, true); // Capture Phase
    }

    function updateState(container, checkboxInput) {
        // Verifica se realmente marcou (Lê a classe do componente Angular)
        const wrapper = checkboxInput.closest('mat-checkbox');
        const isChecked = wrapper.classList.contains('mat-checkbox-checked') || checkboxInput.checked;

        // Elemento visual para pintar
        let visualTarget = container.querySelector('.tl-documento') || container.querySelector('.tl-subitem-detalhe');
        if (visualTarget && visualTarget.closest('a')) visualTarget = visualTarget.closest('a');
        if (!visualTarget) visualTarget = container; // Fallback

        // ID único
        const id = container.id || Math.random();

        if (isChecked) {
            visualTarget.classList.add('pje-selected-v22');
            // Opcional: Adicionar à lista visual (apenas cosmético)
        } else {
            visualTarget.classList.remove('pje-selected-v22');
        }

        updateUIList();
    }

    function updateUIList() {
        const list = document.getElementById('list-v22');
        const count = document.getElementById('count-v22');

        // Conta baseada na verdade do DOM (Checkboxes marcados na timeline)
        const allChecked = document.querySelectorAll('.tl-item-anexo mat-checkbox.mat-checkbox-checked, .tl-item-desc mat-checkbox.mat-checkbox-checked');

        count.innerText = allChecked.length;
        list.innerHTML = '';

        if (allChecked.length === 0) {
            list.innerHTML = '<div style="text-align:center; color:#888; padding:10px;">Nada selecionado</div>';
            return;
        }

        allChecked.forEach(chk => {
            const row = chk.closest('.tl-item-anexo, .tl-item-desc');
            let text = "Documento";
            if (row) {
                const t = row.querySelector('.tl-subitem-detalhe, .tl-documento');
                if(t) text = t.innerText.replace(/\s+/g, ' ').trim();
            }
            const div = document.createElement('div');
            div.innerText = `✓ ${text.substring(0, 35)}...`;
            div.style.padding = '3px';
            div.style.borderBottom = '1px solid #eee';
            list.appendChild(div);
        });
    }

    // --- 6. DOWNLOAD ---
    function doNativeDownload() {
        const dlBtn = document.getElementById('baixar-docs-selecionados');
        if (!dlBtn) return alert('Selecione algo primeiro.');

        dlBtn.click();

        // Tenta clicar na opção do menu
        let attempts = 0;
        const interval = setInterval(() => {
            attempts++;
            const items = document.querySelectorAll('button[role="menuitem"]');
            for (let item of items) {
                if (item.innerText.match(/PDF .nico/i)) {
                    item.click();
                    clearInterval(interval);
                    document.body.click(); // Fecha menu
                    return;
                }
            }
            if (attempts > 10) clearInterval(interval); // Desiste após 2s
        }, 200);
    }

    // Start Check
    setInterval(() => {
        if (!document.getElementById('btn-activate-v22') && !document.getElementById('pje-panel-v22')) {
            init();
        }
    }, 2000);

})();
