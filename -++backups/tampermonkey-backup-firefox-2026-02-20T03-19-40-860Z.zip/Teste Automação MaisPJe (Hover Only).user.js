// ==UserScript==
// @name         Teste Automação MaisPJe (Hover Only)
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Ativa menu hover do MaisPJe e clica em botões específicos sem clicar no martelo
// @match        https://pje.trt2.jus.br/pjekz/processo/*/detalhe/*
// @match        https://pje.trt2.jus.br/pjekz/processo/*/detalhe
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const wait = (ms) => new Promise(r => setTimeout(r, ms));

    // Botão de teste na tela
    const btn = document.createElement('button');
    btn.textContent = '+PJe Test';
    btn.style.cssText = 'position:fixed;top:150px;right:20px;z-index:99999;padding:10px;background:purple;color:white;cursor:pointer;font-weight:bold;border:none;border-radius:5px;box-shadow:0 2px 5px rgba(0,0,0,0.3);';
    btn.onclick = executarTeste;
    document.body.appendChild(btn);

    async function executarTeste() {
        console.log('[TESTE] Iniciando...');

        // 1. Encontrar o Martelo (Gavel)
        const gavelLink = document.querySelector('#maisPJe_bt_detalhes_concluso');

        if (!gavelLink) {
            alert('Botão Martelo (Gavel) não encontrado! Verifique se a extensão MaisPJe está ativa.');
            return;
        }

        // 2. Simular HOVER APENAS (Sem Click)
        console.log('[TESTE] Simulando Hover no Martelo...');

        // Dispara eventos de mouse para simular o hover real
        const eventOptions = { bubbles: true, cancelable: true, view: window };
        gavelLink.dispatchEvent(new MouseEvent('mouseover', eventOptions));
        gavelLink.dispatchEvent(new MouseEvent('mouseenter', eventOptions));
        gavelLink.dispatchEvent(new MouseEvent('mousemove', eventOptions)); // Alguns scripts exigem movimento

        // 3. Esperar o container de botões aparecer
        console.log('[TESTE] Aguardando menu aparecer...');
        const container = await esperarElemento('maispjecontaineraa');

        if (!container) {
            alert('Menu do MaisPJe não abriu após o hover!');
            return;
        }

        // 4. Procurar e Clicar no botão "Genérico"
        // Procura pelo atributo name="Genérico" conforme seu HTML
        const botaoAlvo = container.querySelector('button[name="Genérico"]');

        if (botaoAlvo) {
            console.log('[TESTE] Botão "Genérico" encontrado! Clicando...');

            // Destaque visual antes do clique para confirmação
            botaoAlvo.style.border = '3px solid red';
            botaoAlvo.style.boxShadow = '0 0 10px red';

            await wait(500); // Pequeno delay para visualização
            botaoAlvo.click();
        } else {
            console.error('[TESTE] Botão "Genérico" não encontrado dentro do container!');
            alert('Botão "Genérico" não encontrado!');
        }
    }

    function esperarElemento(selector, timeout = 3000) {
        return new Promise((resolve) => {
            const start = Date.now();
            const interval = setInterval(() => {
                const el = document.querySelector(selector);
                // Verifica se existe e se não está oculto (display: none)
                if (el && el.offsetParent !== null) {
                    clearInterval(interval);
                    resolve(el);
                }
                if (Date.now() - start > timeout) {
                    clearInterval(interval);
                    console.warn(`Timeout esperando elemento: ${selector}`);
                    resolve(null);
                }
            }, 100);
        });
    }

})();
