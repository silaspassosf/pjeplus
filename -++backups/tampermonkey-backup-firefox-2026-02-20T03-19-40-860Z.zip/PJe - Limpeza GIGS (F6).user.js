// ==UserScript==
// @name         PJe - Limpeza GIGS (F6)
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Limpa XS/Silas/Dom.E ao pressionar F6
// @author       Você
// @match        https://pje.trt2.jus.br/pjekz/processo/*/detalhe*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    console.log('[GIGS_F6] Carregado. Pressione F6 para limpar.');

    document.addEventListener('keydown', function(e) {
        // Verifica se a tecla pressionada é F6
        if (e.key === 'F6') {
            e.preventDefault(); // Previne ação padrão do navegador (selecionar barra de endereço)
            console.log('[GIGS_F6] Tecla F6 detectada! Executando limpeza...');

            // Exibe aviso visual imediato de início
            showToast('Iniciando limpeza...', '#ff9800'); // Laranja

            // Executa o bookmarklet original
            runCleanup();
        }
    });

    function showToast(text, color) {
        let t = document.createElement('div');
        t.textContent = text;
        t.style.cssText = `position:fixed;top:10px;right:10px;background:${color};color:#fff;padding:12px;z-index:99999;border-radius:4px;font-weight:bold;box-shadow:0 2px 5px rgba(0,0,0,0.3);font-family:sans-serif;`;
        document.body.appendChild(t);
        setTimeout(() => t.remove(), 3000);
    }

    function runCleanup() {
        (async function(){
            console.log('[GIGS_CLEANUP] Iniciando...');
            let removedCount=0;

            function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }

            // Loop principal
            let hasMore=true;
            while(hasMore){
                hasMore=false; // Assume que acabou, a menos que encontre algo para remover

                // Seleciona linhas visíveis da tabela de atividades
                const rows = document.querySelectorAll('pje-gigs-atividades table tbody tr');

                for(let row of rows){
                    try{
                        if(row.style.display==='none') continue;

                        // Captura descrição
                        const descEl = row.querySelector('td .descricao');
                        if(!descEl) continue;
                        const desc = descEl.textContent.trim();

                        // Captura ícones de prazo
                        const alerta = row.querySelector('pje-gigs-alerta-prazo .prazo');
                        if(!alerta) continue;

                        // Identifica status
                        const isVencida = alerta.querySelector('i.danger.fa-clock.far');
                        const isSemPrazo = alerta.querySelector('i.fa.fa-pen.atividade-sem-prazo');
                        const isVerde = alerta.querySelector('i.fa-clock.far.success');

                        if(isVerde) continue; // Pula atividades "no prazo" (verdes)

                        // Identifica conteúdo
                        const descLower = desc.toLowerCase();
                        const hasXsOrSilas = descLower.includes('xs') || descLower.includes('silas');
                        const hasDomE = desc.includes('Dom.E');

                        // Lógica de Remoção
                        // 1. Vencida E (XS ou Silas)
                        // 2. Sem Prazo E (XS ou Silas ou Dom.E)
                        const deveRemover = (isVencida && hasXsOrSilas) || (isSemPrazo && (hasXsOrSilas || hasDomE));

                        if(deveRemover){
                            console.log(`[GIGS_CLEANUP] Removendo: ${desc}`);

                            // 1. Clicar na Lixeira
                            const btnExcluir = row.querySelector('button[mattooltip="Excluir Atividade"]');
                            if(btnExcluir) {
                                btnExcluir.click();
                                await sleep(600); // Espera modal abrir

                                // 2. Confirmar no Modal ("Sim")
                                // Procura botão 'Sim' de várias formas para garantir
                                let btnSim = Array.from(document.querySelectorAll('button')).find(b => b.textContent.trim() === 'Sim');

                                if(btnSim) {
                                    btnSim.click();
                                    removedCount++;
                                    await sleep(1000); // Espera modal fechar e lista atualizar

                                    hasMore = true; // Reinicia o loop pois o DOM mudou
                                    break; // Sai do for para re-escanear a tabela
                                }
                            }
                        }
                    } catch(e) {
                        console.error('[GIGS_CLEANUP] Erro na linha:', e);
                    }
                }
            }

            console.log(`[GIGS_CLEANUP] Fim. Removidos: ${removedCount}`);
            if(removedCount > 0) showToast(`Limpeza concluída: ${removedCount} removidos!`, '#4caf50'); // Verde
            else showToast('Nenhuma atividade para limpar.', '#2196f3'); // Azul

        })();
    }
})();
